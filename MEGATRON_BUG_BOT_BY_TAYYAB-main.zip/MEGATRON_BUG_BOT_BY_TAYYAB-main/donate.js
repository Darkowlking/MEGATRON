module.exports = async function ({ reply }) {
  const msg = `
💸 *SUPPORT ME / DONATE* 💸

If you love this bot and want to support my work, consider donating 🫶

🧧 *EasyPaisa:* *Bro, buy a gift for your girlfriend with this money 🙂 If you don’t have a girlfriend, then buy poison with this money and end it.*
🏦 *JazzCash:* *Bruh 🥰 Be happy With Your GF*
💳 *Bank:* *Ask To Your Girlfriend*

📺 *YouTube Channel:* https://www.youtube.com/@demoneye_official

Thanks for your support! 🙏

> 𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦ ✓
`;

  reply(msg);
};