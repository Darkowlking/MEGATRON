module.exports = async function({ reply }) {
  reply("✅ *No users are currently banned.*\n\n> 𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦ ✓");
};