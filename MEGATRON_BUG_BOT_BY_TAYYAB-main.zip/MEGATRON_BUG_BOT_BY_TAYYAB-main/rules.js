module.exports = async function ({ reply }) {
  const rules = `
📜 *BOT RULES* 📜

1️⃣ Don't spam commands.
2️⃣ Don't abuse the bot or its users.
3️⃣ Don't send fake crash/lag commands.
4️⃣ Use bugs only if you're the owner.
5️⃣ Respect group admins and members.
6️⃣ Bot isn't responsible for any misuse.

📌 Follow the rules or get banned.

🔗 *Official YouTube:* https://www.youtube.com/@demoneye_official

> 𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦ ✓
`;

  reply(rules);
};