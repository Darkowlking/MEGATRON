module.exports = async function ({ reply }) {
  reply(
`👑 *Bot Owner Name:* Lucifer-x11 
🔮 *About Me:*  
I am *Lucifer*, the creator of *MegaTron WhatsApp Bot*.  
A passionate tech enthusiast, full-stack developer, and bug researcher.  
I specialize in creating powerful WhatsApp automation bots, security tools,  
and crafting unique UI crash exploits that shake the platform.  
My mission is to push the boundaries of what WhatsApp bots can do  
with style, power, and full control.

📺 *YouTube Channel:* https://www.youtube.com/@demoneye_official  

> 𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦ ✓`
  );
};
