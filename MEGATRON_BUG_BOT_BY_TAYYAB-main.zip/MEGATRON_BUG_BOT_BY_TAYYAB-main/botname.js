module.exports = async function ({ reply }) {
  reply(
`🤖 *Bot Name:* MeGaTron
👑 *Developer:* Tayyab
📺 *YouTube:* https://www.youtube.com/@demoneye_official

> 𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦ ✓`
  );
};