module.exports = async function ({ reply }) {
  const text = `
╭────〔 👑 *OWNER DETAILS* 〕────╮
│
│ 🤴 *Name:*  𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 𓆩❦𓆪
│ 🧠 *Intro:*  A creative tech enthusiast, coder,
│     exploit researcher & the mind behind
│     𝗠𝗘𝗚𝗔𝗧𝗥𝗢𝗡 - WhatsApp Bot 🤖
│
│ 🤖 *Bot Name:*  𝗠𝗘𝗚𝗔𝗧𝗥𝗢𝗡 - Powered by DEMONEYE 
│ 📺 *YouTube:*  
│   https://www.youtube.com/@demoneye_official
│
│ 💬 *Telegram Channels:*
│ 🔹 *𝗘𝗫𝗣𝗟𝗢𝗜𝗧𝗦 😲*
│   https://t.me/Next_DYS
│ 🔸 * BACKUP 😄*
│   https://t.me/BACKUPFILEx11
│
│ 📸 *Socials:*
│ 🌐 *Instagram:* @itz__abhi__0018
│
╰──────〔 ⚡ 𝗠𝗘𝗚𝗔𝗧𝗥𝗢𝗡 𝗕𝗢𝗧 ⚡ 〕──────╯

> *𝐋 𝐔 𝐂 𝐈 𝐅 𝐄 𝐑 ❦️ ✓*
`;
  reply(text);
};